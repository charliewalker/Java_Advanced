package Controller;

public interface DeleteBehavior {
    void DeleteEmployees(int id);
}
