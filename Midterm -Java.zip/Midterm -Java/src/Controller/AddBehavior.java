package Controller;

public interface AddBehavior {
    void OpenDialogAddEmployees();
}
