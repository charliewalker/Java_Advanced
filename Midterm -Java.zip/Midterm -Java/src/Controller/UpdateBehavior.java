package Controller;

import Model.Employee;

public interface UpdateBehavior {
    void UpdateEmployees(Employee employee);
}
