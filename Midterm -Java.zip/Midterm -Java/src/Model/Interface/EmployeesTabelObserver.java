package Model.Interface;

import Model.Employee;

import java.util.List;

public interface EmployeesTabelObserver {
    void updateobserver(List<Employee> list);
}
